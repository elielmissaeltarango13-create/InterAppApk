PASOS MÓVIL (SÚPER CORTOS):
1) Sube esta carpeta a un repo nuevo en GitHub (desde tu celular).
2) Entra a la pestaña Actions -> Build APK (OneTap) -> Run workflow.
3) Cuando termine, baja el artifact InterpApp-APK (el .apk). ¡Listo!
